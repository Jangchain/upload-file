importScripts('https://storage.googleapis.com/workbox-cdn/releases/6.1.0/workbox-sw.js');

workbox.setConfig({
    debug: false
});

const { setDefaultHandler } = workbox.routing;
const { StaleWhileRevalidate } = workbox.strategies;
const { warmStrategyCache } = workbox.recipes;
const { clientsClaim } = workbox.core;

self.skipWaiting();
clientsClaim();

// Normalize cache key URLs to:
// - drop query parameters
// - for URLs ending in '/', append 'index.html'
async function cacheKeyWillBeUsed({ request }) {
    const url = new URL(request.url);
    if (url.pathname.endsWith('/')) {
        return url.origin + url.pathname + 'index.html';
    }
    return url.origin + url.pathname;
}

const strategy = new StaleWhileRevalidate({
    plugins: [
        { cacheKeyWillBeUsed },
    ],
});

// Ensure that an initial set of URLs are cached,
// so that the PWA works offline immediately.
const urls = [
    '/index.html',
    '/manifest.json',
    '/script.js',
    '/style.css',
];
warmStrategyCache({ urls, strategy });

// Use stale-while-revalidate for all requests.
setDefaultHandler(strategy);